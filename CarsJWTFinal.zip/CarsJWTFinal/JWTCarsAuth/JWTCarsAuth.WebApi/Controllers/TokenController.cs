﻿using JWTAuth.WebApi.Services;
using JWTCarsAuth.WebApi.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace JWTAuth.WebApi.Controllers
{
    [Route("api/token")]
    [ApiController]
    //[EnableCors(""_myAllowSpecificOrigins"")]
    public class TokenController : ControllerBase
    {
        public IConfiguration _configuration;
        private readonly DatabaseContext _context;
        private readonly TokenService _tokenService;

        public TokenController(IConfiguration config, DatabaseContext context, TokenService tokenService)
        {
            _configuration = config;
            _context = context;
            _tokenService = tokenService;
        }

        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> Login(User _userData)
        {
            if (_userData != null && _userData.UserName != null && _userData.Password != null)
            {
                var user = await GetUser(_userData.UserName, _userData.Password);

                if (user != null)
                {
                    var accessToken = _tokenService.CreateToken(user);

                    var resp = new AuthorizationResponse
                    {
                        UserId = user.Id.ToString(),
                        AuthorizationToken = accessToken,
                        RefreshToken = string.Empty
                    };

                    return Ok(resp);
                }
                else
                {
                    //return BadRequest("Invalid credentials");
                    return BadRequest();
                }
            }
            else
            {
                return BadRequest();
            }
        }

        private async Task<User> GetUser(string UserName, string password)
        {
            return await _context.Users.FirstOrDefaultAsync(u => u.UserName == UserName && u.Password == password);
        }

        public class AuthorizationResponse {
            public string UserId { get; set; }
            public string AuthorizationToken { get; set; }
            public string RefreshToken { get; set; }
        }

    }
}
