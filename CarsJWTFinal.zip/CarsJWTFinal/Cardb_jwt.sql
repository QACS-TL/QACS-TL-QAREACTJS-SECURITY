USE [master]
GO

/****** Object:  Database [cardb_jwt]    Script Date: 16/01/2024 16:04:19 ******/
DROP DATABASE [cardb_jwt]
GO

/****** Object:  Database [cardb_jwt]    Script Date: 16/01/2024 16:04:19 ******/
CREATE DATABASE [cardb_jwt]
GO


USE [cardb_jwt]
GO
/****** Object:  Schema [cardb_jwt]    Script Date: 16/01/2024 16:03:36 ******/
CREATE SCHEMA [cardb_jwt]
GO
/****** Object:  Table [cardb_jwt].[car]    Script Date: 16/01/2024 16:03:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [cardb_jwt].[car](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[brand] [nvarchar](255) NULL,
	[colour] [nvarchar](255) NULL,
	[model] [nvarchar](255) NULL,
	[price] [int] NOT NULL,
	[registration_number] [nvarchar](255) NULL,
	[year] [int] NOT NULL,
	[owner] [int] NULL,
 CONSTRAINT [PK_car_id] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [cardb_jwt].[owner]    Script Date: 16/01/2024 16:03:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [cardb_jwt].[owner](
	[ownerid] [int] IDENTITY(1,1) NOT NULL,
	[firstname] [nvarchar](255) NULL,
	[lastname] [nvarchar](255) NULL,
 CONSTRAINT [PK_owner_ownerid] PRIMARY KEY CLUSTERED 
(
	[ownerid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [cardb_jwt].[user]    Script Date: 16/01/2024 16:03:36 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [cardb_jwt].[user](
	[id] [int] IDENTITY(3,1) NOT NULL,
	[password] [nvarchar](255) NOT NULL,
	[role] [nvarchar](255) NOT NULL,
	[username] [nvarchar](255) NOT NULL,
 CONSTRAINT [PK_user_id] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [cardb_jwt].[car] ON 
GO
INSERT [cardb_jwt].[car] ([id], [brand], [colour], [model], [price], [registration_number], [year], [owner]) VALUES (1, N'Ford', N'Red', N'Focus', 59000, N'AB17 SWD', 2017, 1)
GO
INSERT [cardb_jwt].[car] ([id], [brand], [colour], [model], [price], [registration_number], [year], [owner]) VALUES (2, N'Audi', N'White', N'TT', 29000, N'DE14 VCL', 2014, 1)
GO
INSERT [cardb_jwt].[car] ([id], [brand], [colour], [model], [price], [registration_number], [year], [owner]) VALUES (3, N'BMW', N'Silver', N'5 Series', 39000, N'KK18 UYR', 2018, 2)
GO
INSERT [cardb_jwt].[car] ([id], [brand], [colour], [model], [price], [registration_number], [year], [owner]) VALUES (5, N'BMW', N'White', N'4 Series', 14000, NULL, 2016, NULL)
GO
INSERT [cardb_jwt].[car] ([id], [brand], [colour], [model], [price], [registration_number], [year], [owner]) VALUES (8, N'Ford', N'White', N'Mondeo', 19000, NULL, 2014, NULL)
GO
INSERT [cardb_jwt].[car] ([id], [brand], [colour], [model], [price], [registration_number], [year], [owner]) VALUES (10, N'Vauxhall', N'Yellow', N'Corsa', 6000, NULL, 2020, NULL)
GO
SET IDENTITY_INSERT [cardb_jwt].[car] OFF
GO
SET IDENTITY_INSERT [cardb_jwt].[owner] ON 
GO
INSERT [cardb_jwt].[owner] ([ownerid], [firstname], [lastname]) VALUES (1, N'Julie', N'Dooley')
GO
INSERT [cardb_jwt].[owner] ([ownerid], [firstname], [lastname]) VALUES (2, N'Bob', N'Robinson')
GO
SET IDENTITY_INSERT [cardb_jwt].[owner] OFF
GO
SET IDENTITY_INSERT [cardb_jwt].[user] ON 
GO
INSERT [cardb_jwt].[user] ([id], [password], [role], [username]) VALUES (3, N'adminpass', N'ADMIN', N'admin')
GO
INSERT [cardb_jwt].[user] ([id], [password], [role], [username]) VALUES (4, N'userpass', N'USER', N'user')
GO
SET IDENTITY_INSERT [cardb_jwt].[user] OFF
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [user$UK_sb8bbouer5wak8vyiiy4pf2bx]    Script Date: 16/01/2024 16:03:36 ******/
ALTER TABLE [cardb_jwt].[user] ADD  CONSTRAINT [user$UK_sb8bbouer5wak8vyiiy4pf2bx] UNIQUE NONCLUSTERED 
(
	[username] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
GO
ALTER TABLE [cardb_jwt].[car] ADD  CONSTRAINT [DF__car__brand__29572725]  DEFAULT (NULL) FOR [brand]
GO
ALTER TABLE [cardb_jwt].[car] ADD  CONSTRAINT [DF__car__colour__2A4B4B5E]  DEFAULT (NULL) FOR [colour]
GO
ALTER TABLE [cardb_jwt].[car] ADD  CONSTRAINT [DF__car__model__2B3F6F97]  DEFAULT (NULL) FOR [model]
GO
ALTER TABLE [cardb_jwt].[car] ADD  CONSTRAINT [DF__car__registratio__2C3393D0]  DEFAULT (NULL) FOR [registration_number]
GO
ALTER TABLE [cardb_jwt].[car] ADD  CONSTRAINT [DF__car__owner__2D27B809]  DEFAULT (NULL) FOR [owner]
GO
ALTER TABLE [cardb_jwt].[owner] ADD  CONSTRAINT [DF__owner__firstname__2E1BDC42]  DEFAULT (NULL) FOR [firstname]
GO
ALTER TABLE [cardb_jwt].[owner] ADD  CONSTRAINT [DF__owner__lastname__2F10007B]  DEFAULT (NULL) FOR [lastname]
GO
ALTER TABLE [cardb_jwt].[car]  WITH CHECK ADD  CONSTRAINT [car$FK2mqqwvxtowv4vddvtsmvtiqa2] FOREIGN KEY([owner])
REFERENCES [cardb_jwt].[owner] ([ownerid])
GO
ALTER TABLE [cardb_jwt].[car] CHECK CONSTRAINT [car$FK2mqqwvxtowv4vddvtsmvtiqa2]
GO
EXEC sys.sp_addextendedproperty @name=N'MS_SSMA_SOURCE', @value=N'cardb_jwt.car' , @level0type=N'SCHEMA',@level0name=N'cardb_jwt', @level1type=N'TABLE',@level1name=N'car'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_SSMA_SOURCE', @value=N'cardb_jwt.owner' , @level0type=N'SCHEMA',@level0name=N'cardb_jwt', @level1type=N'TABLE',@level1name=N'owner'
GO
EXEC sys.sp_addextendedproperty @name=N'MS_SSMA_SOURCE', @value=N'cardb_jwt.`user`' , @level0type=N'SCHEMA',@level0name=N'cardb_jwt', @level1type=N'TABLE',@level1name=N'user'
GO
