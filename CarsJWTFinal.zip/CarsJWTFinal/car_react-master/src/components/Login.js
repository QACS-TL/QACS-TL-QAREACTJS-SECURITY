import React, { useState } from 'react';
import {SERVER_URL} from '../constants.js';
import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import Carlist from './Carlist.jsx';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from "axios";

const Login = () => {
  const [user, setUser] = useState({username: '', password: ''})
  const [isAuthenticated, setAuth] = useState(false);
 
  const handleChange = (event) => {
    setUser({...user, [event.target.name] : event.target.value})
  }

  const login = () => {
    axios
      .post(SERVER_URL + 'api/token/login', user)
      .then((res) => {
        if (res.data.authorizationToken) {
         
          console.log("Token data: " + res.data.authorizationToken)
          const jwtToken = res.data.authorizationToken;
          if (jwtToken) {
            sessionStorage.setItem("jwt", jwtToken);
            setAuth(true);
          }
          else {
          toast.warn('Check your username and password 1', {
            position: toast.POSITION.BOTTOM_LEFT
          }) 
        }
      }
      })
      .catch((error)=>{
        console.log(error.message)
        toast.warn('Check your username and password', {
          position: toast.POSITION.BOTTOM_LEFT
        })
      })
  }  

  if (isAuthenticated === true) {
    return (<Carlist />)
  }
  else {
    return (
      <div>
        <TextField name="username" 
          label="Username" onChange={handleChange} /><br/> 
        <TextField type="password" name="password" 
          label="Password" onChange={handleChange} /><br/><br/> 
        <Button variant="outlined" color="primary" 
          onClick={login}>
          Login
        </Button>
        <ToastContainer autoClose={5000} /> 
      </div>
    );
  }
}

export default Login;