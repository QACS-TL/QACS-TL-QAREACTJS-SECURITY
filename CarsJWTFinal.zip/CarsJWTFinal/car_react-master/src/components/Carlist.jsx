import React from "react";
//import { Link } from "react-router-dom"
import {SERVER_URL} from '../constants.js'
import {useState, useEffect, useCallback} from 'react';
import ReactTable from "react-table";
import 'react-table/react-table.css';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import AddCar from './AddCar.js';
import EditCar from './EditCar.js';
import { CSVLink } from 'react-csv';
import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Grid';
import axios from 'axios';

function CarList() {
  const [allCars, setAllCars] = useState([])

  const getCars = () => {
    // Read the token from the session storage
    // and include it to Authorization header
    const token = sessionStorage.getItem("jwt");
    console.log(token)
    axios.get(SERVER_URL + 'api/cars', { headers: {"Authorization" : `Bearer ${token}`} })
    .then(response => {
      console.log(response.data)
      setAllCars(response.data)
    //.catch(err => console.error(err)); 
    })
  }

  useEffect(() => {
    //Replaces to CDM and CDU
   setTimeout(() => {
      getCars();
    }, 200);
  }, []);

   // Delete car
  const onDelClick = (car) => {
    console.log("DELETE: "  + car.id)
    if (window.confirm('Are you sure to delete?')) {
      const token = sessionStorage.getItem("jwt");
      axios.delete(SERVER_URL + 'api/cars/' + car.id, { headers: {"Authorization" : `Bearer ${token}`} })
      .then(res => {
        toast.success("Car deleted", {
          position: toast.POSITION.BOTTOM_LEFT
        })
        getCars()
      })
      .catch(err => {
        toast.error("Error when deleting", {
          position: toast.POSITION.BOTTOM_LEFT
        });
        console.error(err)
      }) 
    } 
  }
  
  // Add new car
  const addCar = (car) => {
    const token = sessionStorage.getItem("jwt");
    axios.post(SERVER_URL + 'api/cars', car, { headers: {"Authorization" : `Bearer ${token}`} })
    .then(res => {
      toast.success("New car added", {
        position: toast.POSITION.BOTTOM_LEFT
      })
      getCars()
      car = null
    })
    .catch(
      err => {console.error(err)
      toast.error("Error when saving", {
        position: toast.POSITION.BOTTOM_LEFT
      })}); 
  }

    // Update car
    const updateCar = (car, link) => {
      const token = sessionStorage.getItem("jwt");
      axios.put(SERVER_URL + 'api/cars/' + car.id, car, { headers: {"Authorization" : `Bearer ${token}`} })
      .then(res => {
        toast.success("Changes saved", {
          position: toast.POSITION.BOTTOM_LEFT
        })
        getCars()
      })
      .catch(err => 
        toast.error("Error when saving", {
          position: toast.POSITION.BOTTOM_LEFT
        }) 
      )
    }
  
  const columns = [{
    Header: 'Id',
    accessor: 'id'
  }, {
    Header: 'Brand',
    accessor: 'brand',
  },{
    Header: 'Model',
    accessor: 'model',
  }, {
    Header: 'Colour',
    accessor: 'colour',
  }, {
    Header: 'Year',
    accessor: 'year',
  }, {
    Header: 'Price €',
    accessor: 'price',
  }, {
    sortable: false,
    filterable: false,
    width: 100,      
    accessor: '_links.self.href',
    Cell: ({value, row}) => (<EditCar car={row} link={value} updateCar={updateCar} fetchCars={allCars} />),
  }, {
    sortable: false,
    filterable: false,
    width: 100,
    accessor: '_links.self.href',
    Cell: ({value, row}) => (<Button size="small" color="secondary" 
      onClick={()=>{onDelClick(row)}}>Delete</Button>)
  }]

  return (
    <div className="App">
      <Grid container>
        <Grid item>
          <AddCar addCar={addCar} fetchCars={allCars} />
        </Grid>
        <Grid item style={{padding: 15}}>
          <CSVLink data={allCars} separator=";">Export CSV</CSVLink>
        </Grid>
      </Grid>
      <ReactTable data={allCars} columns={columns} 
        filterable={true}/>
      <ToastContainer autoClose={1500} /> 
    </div>
  );
}

export default CarList