//export const SERVER_URL = 'http://52.211.168.107:8888/'
export const SERVER_URL = 'https://localhost:8762/'
//export const SERVER_URL = 'http://localhost:5214/'