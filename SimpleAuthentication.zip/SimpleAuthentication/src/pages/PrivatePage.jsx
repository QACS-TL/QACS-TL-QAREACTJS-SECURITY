import React from 'react';
import { useAuth } from '../components/AuthContext';

const PrivatePage = () => {
  const { isAuthenticated, logout } = useAuth();

  if (!isAuthenticated) {
    return <p>You are not authenticated. Please login.</p>;
  }

  return (
    <div className="page">
      <h2>Private Page</h2>
      <p>Welcome to the secure area!</p>
      <button className="button" onClick={logout}>Logout</button>
    </div>
  );
};

export default PrivatePage;
