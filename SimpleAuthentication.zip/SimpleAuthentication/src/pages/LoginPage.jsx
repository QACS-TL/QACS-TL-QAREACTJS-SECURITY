import React from 'react';
import { useAuth } from '../components/AuthContext';
import '../App.css'

const LoginPage = () => {
  const { login } = useAuth();

  const handleLogin = () => {
    // You might want to implement authentication logic here
    login();
  };

  return (
    <div className="page">
      <h2>Login Page</h2>
      <button className="button" onClick={handleLogin}>Login</button>
    </div>
  );
};

export default LoginPage;
