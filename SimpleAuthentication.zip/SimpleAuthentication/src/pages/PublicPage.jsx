export const Public = () => {

    return (
         <div className="page">
              <h2>Public page</h2>
              <p>This is the text for the public page</p>
         </div>
    )
}

export default Public