import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from './components/Navbar';
import { AuthProvider } from "./components/AuthContext";
import LoginPage from "./pages/LoginPage";
import PrivatePage from "./pages/PrivatePage";
import PublicPage from "./pages/PublicPage";
import HomePage from "./pages/HomePage";
import { RenderHeader } from "./components/Header";
//import { RenderMenu } from "./components/Navigation";
import './App.css'

const App = () => {
  return (
    <>
      <div className="App">
        <BrowserRouter>
          <AuthProvider>
            <RenderHeader />
            <Navbar />
        
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/public" element={<PublicPage />} />
              <Route path="/private" element={<PrivatePage />} />
              <Route path="/login" element={<LoginPage />} />
            </Routes>
          </AuthProvider>
        </BrowserRouter>
      </div>
    </>
  );
};

export default App;
