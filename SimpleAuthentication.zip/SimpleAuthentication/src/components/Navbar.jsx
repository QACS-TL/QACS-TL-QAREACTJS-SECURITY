import React from "react";

import { Link } from "react-router-dom";
import "../App.css";

export default function Navbar() {
  return (
    <div className="menu">
      <nav>
        <h1>React App</h1>
        <div>
          <Link to="/">Home</Link>
        </div>
        <div className="menuitem">
          <Link to="/public">Public</Link>
        </div>
        <div className="menuitem">
          <Link to="/private">Private</Link>
        </div>
        <div className="menuitem">
          <Link to="/login">Login</Link>
        </div>
      </nav>
    </div>
  );
}
